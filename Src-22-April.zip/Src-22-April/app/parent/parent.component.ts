import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
num=0;
thankYouMsg="";

  constructor() { }

  ngOnInit(): void {
  }
SendToChild(){
  this.num++;
}

ReceiveThanks(event){
this.thankYouMsg=event;
console.log(this.thankYouMsg)
}

}
