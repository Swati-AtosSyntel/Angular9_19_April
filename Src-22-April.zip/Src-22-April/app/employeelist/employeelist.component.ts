import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { IEmployee } from '../employee/employee';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {
employees:IEmployee[];
selectedEmployeeCountRadioButtonValue:string="All";
selectedgenderValue:number;
  constructor(employeeService:EmployeeService) { 
  this.employees=employeeService.getEmployees();
  }

  ngOnInit(): void {
  }
  getTotalEmployeesCount():number{
    return this.employees.length;
  }
  getMaleEmployeesCount():number{
    return this.employees.filter(e=>e.gender==1).length;
  }
  getFemaleEmployeesCount():number{
    return this.employees.filter(e=>e.gender==2).length;
  }
  trackByEmpId(index:number,employee:any):any{
    return employee.id;
  }
  onEmployeeCountRadioButtonChange(selectedRadioButtonValue:string):void{
    this.selectedEmployeeCountRadioButtonValue=selectedRadioButtonValue;
    if(selectedRadioButtonValue=="All")
    this.selectedgenderValue=0;
    else if(selectedRadioButtonValue=="Male")
    this.selectedgenderValue=1;
    else if(selectedRadioButtonValue=="Female")
    this.selectedgenderValue=2;

  }
}
