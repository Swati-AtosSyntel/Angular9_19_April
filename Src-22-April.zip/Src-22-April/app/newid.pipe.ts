import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'newid'
})
export class NewidPipe implements PipeTransform {

  transform(value:any,num:any): any {
    return value+num;
  }

}


