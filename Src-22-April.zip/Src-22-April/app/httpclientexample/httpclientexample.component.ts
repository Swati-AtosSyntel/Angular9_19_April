import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Repository} from './repository';
@Component({
  selector: 'app-httpclientexample',
  templateUrl: './httpclientexample.component.html',
  styleUrls: ['./httpclientexample.component.css']
})
export class HttpclientexampleComponent implements OnInit {

  repos:Repository[];
  username="swati";
  baseUrl="https://api.github.com/";


  constructor(private httpClient:HttpClient) { 
  
  }
  getRepository(){
    return this.httpClient.get<Repository[]>(
      this.baseUrl+'users/'+this.username+'/repos')
      .subscribe(
        (response)=>{
          console.log("response received");
          console.log(response);
          this.repos=response;
        },
        (error)=>{
          console.log("Request Failed");
        },
        ()=>{
          console.log("Request Completed");
        }
      )
    
  }

  ngOnInit(): void {
    this.getRepository();
  }

}
