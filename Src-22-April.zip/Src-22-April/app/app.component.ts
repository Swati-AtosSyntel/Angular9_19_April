import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  //template:`<h1>
  //{{title}}
  //</h1>
  //`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Welcome to AngularApp';

  flag=true;

  colors=['Red','Green','Blue','Orange'];

  month=1;

  person={fname:"Ashish",lname:"Agrawal"};
  fullName="";

  getFullName(){
    this.fullName=this.person.fname+" "+this.person.lname;
  }
}
