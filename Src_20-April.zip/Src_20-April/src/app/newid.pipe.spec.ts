import { NewidPipe } from './newid.pipe';

describe('NewidPipe', () => {
  it('create an instance', () => {
    const pipe = new NewidPipe();
    expect(pipe).toBeTruthy();
  });
});
